#ifndef SYSTICKDELAY_H_
#define SYSTICKDELAY_H_

#include <stdint.h>
#include <stdbool.h>


// Delay in milliseconds using SysTick timer
void SysTickDelayMs(uint32_t milliseconds);

#endif /* SYSTICKDELAY_H_ */
