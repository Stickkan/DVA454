//*****************************************************************************
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "inc/tm4c129encpdt.h"
#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/adc.h"
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_sysctl.h"
#include "inc/hw_types.h"
#include "inc/hw_uart.h"
#include "driverlib/debug.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"

#include "Assigments/Assignments.h"

//***********************************************************************
//                       Configurations
//***********************************************************************
// Configure the UART. (stolen from lab 2 instructions)
void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    UARTStdioConfig(0, 115200, 16000000);
}

//stolen from eart_echo example
void UARTSend(const uint8_t *pui8Buffer, uint32_t ui32Count)
{
    //
    // Loop while there are more characters to send.
    //
    while (ui32Count--)
    {
        //
        // Write the next character to the UART.
        //
        MAP_UARTCharPutNonBlocking(UART0_BASE, *pui8Buffer++);
    }
}

#define MAX_BUFFER_SIZE 50 // Adjust this to your desired buffer size

char receivedBuffer[MAX_BUFFER_SIZE]; // Buffer to store received characters
volatile int32_t bufferIndex = 0; // Index to keep track of the current position in the buffer
volatile int32_t receivedValue;
void UARTIntHandler(void)
{
    uint32_t ui32Status;

    //
    // Get the interrrupt status.
    //
    ui32Status = MAP_UARTIntStatus(UART0_BASE, true);

    //
    // Clear the asserted interrupts.
    //
    MAP_UARTIntClear(UART0_BASE, ui32Status);

    while (MAP_UARTCharsAvail(UART0_BASE))
    {
        //char receivedChar = UARTCharGetNonBlocking(UART0_BASE);
        char receivedChar;
        if (!(HWREG(UART0_BASE + UART_O_FR) & UART_FR_RXFE))
        {
            //
            // Read and return the next character.
            //
            receivedChar = (HWREG(UART0_BASE + UART_O_DR));
        }

        //UARTCharPutNonBlocking(UART0_BASE, receivedChar); //print out letter
        if (!(HWREG(UART0_BASE + UART_O_FR) & UART_FR_TXFF))
        {
            //
            // Write this character to the transmit FIFO.
            //
            HWREG(UART0_BASE + UART_O_DR) = receivedChar;

        }

        if (receivedChar == ' ')
        {
            UARTprintf(" ---- Sent text: %s \n ", receivedBuffer);
            volatile uint32_t eraseLoop;
            for (eraseLoop = 0; eraseLoop < MAX_BUFFER_SIZE; eraseLoop++)
            {
                receivedBuffer[eraseLoop] = '\0';
            }
            bufferIndex = 0;

        }
        else
        {
            // Add the received character to the buffer.
            if (bufferIndex < (MAX_BUFFER_SIZE - 1))
            {
                receivedBuffer[bufferIndex] = receivedChar;
                bufferIndex++;
            }
        }
    }
}

//*****************************************************************************
//                      Main task 1
//*****************************************************************************
void UART_assig()
{

    ConfigureUART();
    /*
     SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
     SysCtlPWMClockSet(SYSCTL_PWMDIV_1);
     SysCtlPeripheralDisable(SYSCTL_PERIPH_PWM0);
     SysCtlPeripheralReset(SYSCTL_PERIPH_PWM0);
     SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);

     GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);
     GPIOPinConfigure(GPIO_PF2_M0PWM2);

     volatile int32_t LightSwitch = 1;
     receivedValue = 1;
     */
    while (1)
    {
        UARTIntHandler();

    }

}

//-------------------------------
//Task 2

uint32_t g_ui32SysClock;

uint32_t g_ui32Flags;

volatile seconds;
volatile minutes;
volatile hours;
extern void Timer0Handler(void)
{
    UARTprintf("1");
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT); // Clear the timer interrupt.

    //Skapa s� 60 sek �r 1 min.

    //uppdatera tiden typ

    /*
    cOne = HWREGBITW(&g_ui32Flags, 0) ? '1' : '0';
    cTwo = HWREGBITW(&g_ui32Flags, 1) ? '1' : '0';
    UARTprintf("\rT1: %c  T2: %c", cOne, cTwo);
    */
}

void TimerInit()
{
    // enable peripherals
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

    // Timer for 1 second.
    TimerLoadSet(TIMER0_BASE, TIMER_A, g_ui32SysClock);

    //
    //enable and  setup the interrupt for timeout.
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntRegister(INT_TIMER0A, Timer0Handler);

    // Enable the timer.
    IntMasterEnable();
    TimerEnable(TIMER0_BASE, TIMER_A);
}

//main
void stopwatch()
{
    //get clockspeed (example)
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
    SYSCTL_OSC_MAIN |
    SYSCTL_USE_PLL |
    SYSCTL_CFG_VCO_240),
                                            120000000);

    ConfigureUART(); //config uart to write to terminal

    TimerInit(); //config Timer

    UARTprintf("TESTING UART\n");

    //
    // Loop forever while the timer runs.
    //
    while (1)
    {
        //knapp som pausar / resetar


    }
}

