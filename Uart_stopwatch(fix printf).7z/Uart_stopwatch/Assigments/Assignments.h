// Assignments.h
#ifndef ASSIGNMENTS_H
#define ASSIGNMENTS_H

void UART_assig();
void stopwatch();
#endif
